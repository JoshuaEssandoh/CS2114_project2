# Updated SoundStack setup

Use JDK 17. Import this folder with File > Import > General > Existing Projects into Workspace.
Select JavaSE-17 under Project > Properties > Java Build Path > Libraries.
Remove any old Run Configuration Java runtime override; use the project JRE.
Project > Clean, then run SoundStack as a Java Application.

Run SongTest, PlaylistTest, SoundStackTest, and SoundStackRecommendationTest as JUnit tests.
All 105 tests passed with the bundled libraries on Java 17.
The original three test files are unchanged.

Dependencies: jsoup 1.23.2 (original supplied JAR), Web-CAT student.jar
from https://web-cat.org/cta13/code/student.jar, and JUnit 4.10 from Maven Central.
This older student library has overlapping JUnit internals and is incompatible
with JUnit 4.13.2. Keep student.jar before JUnit 4.10 in the classpath.
Do not add another Eclipse JUnit version or the former CS2 project dependencies.
Java 17 prints security-manager deprecation warnings from this older test library;
they are warnings, not test failures. Newer Java versions may reject that library.

Command line (Windows; requires a full JDK):
javac -cp "lib/student.jar;lib/junit-4.10.jar;lib/jsoup-1.23.2.jar" -d bin src/*.java
java -cp "bin;lib/student.jar;lib/junit-4.10.jar;lib/jsoup-1.23.2.jar" org.junit.runner.JUnitCore SongTest PlaylistTest SoundStackTest SoundStackRecommendationTest
java -cp "bin;lib/jsoup-1.23.2.jar" SoundStack
On Linux/macOS replace classpath semicolons with colons.

Menu 0-7 retains original behavior. 8 loads the catalog into the chosen playlist.
10 selects source, genre, count, then target and adds recommendations.
9 stays invalid because an existing test checks it.
Genre searches now call RecommendationEngine.compileGenrePlaylist.
No startup network request occurs. IOException during loading is reported to the user.
RecommendationEngine remains unchanged: imported tracks all receive duration 358
seconds and genre Synth-pop; those values are placeholders, not scraped metadata.
Website availability and changes in its HTML cannot be guaranteed.

Revision assistance: SoundStack integration, dependency configuration and
SoundStackRecommendationTest were GenAI-assisted for Joshua Essandoh.
Original class authorship is preserved. Source and tests compile without errors;
the compiler reports an informational equals(String) diagnostic in SongTest,
which deliberately tests comparison with an unrelated type.

Live Wikipedia loading was attempted here and returned IOException; it was handled
without crashing. Successful external loading was not verified in this environment.
